def main():
    print("Hello from starting-codebase!")


if __name__ == "__main__":
    main()
